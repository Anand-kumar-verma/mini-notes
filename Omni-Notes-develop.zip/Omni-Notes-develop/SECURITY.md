# Security Policy

## Supported Versions

Security updates are supported for the following application's versions:

| Version | Supported          |
| ------- | ------------------ |
| 6.2.x   | :white_check_mark: |
| < 6.2.x   | :x:                |

## Reporting a Vulnerability

Take contact with me through **security@omninotes.app**
